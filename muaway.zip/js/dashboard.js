//localStorage.getItem("key_user");
function vender(){

}

function comprar(){
	
}