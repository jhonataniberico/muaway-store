$(function() {
    var config = {
    apiKey: "AIzaSyDVK-01hSwcO3b-RxELK5kKKz10ZvKIOJA",
    authDomain: "muaway-aed6f.firebaseapp.com",
    databaseURL: "https://muaway-aed6f.firebaseio.com",
    projectId: "muaway-aed6f",
    storageBucket: "muaway-aed6f.appspot.com",
    messagingSenderId: "741671996866",
    appId: "1:741671996866:web:0918109d376b65b66bda5b",
  };
	firebase.initializeApp(config);
});
